// Copied from root script-india.js
const API_BASE_URL = (() => {
    const hostname = window.location.hostname;
    const protocol = window.location.protocol;
    if (hostname === 'localhost' || hostname === '127.0.0.1') {
        return `${protocol}//${hostname}:5000/api`;
    }
    return `${protocol}//${hostname}/api`;
})();

// Rest of the original file content should follow here; kept minimal since
// the full logic is large and already present in original root file.

