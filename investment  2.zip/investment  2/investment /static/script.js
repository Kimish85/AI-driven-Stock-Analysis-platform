// Copied from root script.js
// API Base URL
const API_BASE_URL = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1' 
    ? 'http://localhost:3000/api' 
    : '/api';

// Portfolio data will be loaded from backend
let portfolio = [];

// Investment guides content
const guides = {
    stocks: {
        title: 'Stock Investing Guide',
        content: `
            <h3>Understanding Stock Investing</h3>
            <p>Stocks represent ownership in a company. When you buy a stock, you're purchasing a small piece of that company, called a share.</p>
            
            <h4>Key Concepts:</h4>
            <ul>
                <li><strong>Market Cap:</strong> Total value of all company shares</li>
                <li><strong>P/E Ratio:</strong> Price-to-Earnings ratio indicates valuation</li>
                <li><strong>Dividends:</strong> Regular payments to shareholders</li>
                <li><strong>Volatility:</strong> Price fluctuations over time</li>
            </ul>
            
            <h4>Investment Strategies:</h4>
            <ul>
                <li><strong>Value Investing:</strong> Buy undervalued stocks</li>
                <li><strong>Growth Investing:</strong> Focus on high-growth companies</li>
                <li><strong>Dividend Investing:</strong> Invest in dividend-paying stocks</li>
                <li><strong>Index Investing:</strong> Buy broad market ETFs</li>
            </ul>
            
            <h4>Risk Management:</h4>
            <ul>
                <li>Diversify across different sectors</li>
                <li>Don't invest more than you can afford to lose</li>
                <li>Consider your time horizon</li>
                <li>Regular portfolio rebalancing</li>
            </ul>
        `
    },
    'mutual-funds': {
        title: 'Mutual Funds Guide',
        content: `
            <h3>Understanding Mutual Funds</h3>
            <p>Mutual funds pool money from multiple investors to invest in a diversified portfolio of stocks, bonds, or other securities.</p>
            
            <h4>Types of Mutual Funds:</h4>
            <ul>
                <li><strong>Stock Funds:</strong> Invest primarily in stocks</li>
                <li><strong>Bond Funds:</strong> Invest in government and corporate bonds</li>
                <li><strong>Balanced Funds:</strong> Mix of stocks and bonds</li>
                <li><strong>Index Funds:</strong> Track specific market indices</li>
            </ul>
            
            <h4>Key Metrics:</h4>
            <ul>
                <li><strong>Expense Ratio:</strong> Annual fee as percentage of assets</li>
                <li><strong>Load:</strong> Sales commission (avoid no-load funds)</li>
                <li><strong>NAV:</strong> Net Asset Value per share</li>
                <li><strong>Performance:</strong> Historical returns</li>
            </ul>
            
            <h4>Advantages:</h4>
            <ul>
                <li>Professional management</li>
                <li>Instant diversification</li>
                <li>Accessibility for small investors</li>
                <li>Liquidity</li>
            </ul>
        `
    },
    crypto: {
        title: 'Cryptocurrency Guide',
        content: `
            <h3>Understanding Cryptocurrency</h3>
            <p>Cryptocurrencies are digital or virtual currencies that use cryptography for security and operate on decentralized networks.</p>
            
            <h4>Popular Cryptocurrencies:</h4>
            <ul>
                <li><strong>Bitcoin (BTC):</strong> First and most well-known cryptocurrency</li>
                <li><strong>Ethereum (ETH):</strong> Platform for smart contracts and dApps</li>
                <li><strong>Cardano (ADA):</strong> Research-driven blockchain platform</li>
                <li><strong>Solana (SOL):</strong> High-performance blockchain</li>
            </ul>
            
            <h4>Investment Considerations:</h4>
            <ul>
                <li><strong>Volatility:</strong> Extreme price fluctuations</li>
                <li><strong>Regulation:</strong> Evolving regulatory environment</li>
                <li><strong>Technology Risk:</strong> New and unproven technology</li>
                <li><strong>Security:</strong> Risk of hacking and fraud</li>
            </ul>
            
            <h4>Storage Options:</h4>
            <ul>
                <li><strong>Hot Wallets:</strong> Online storage (convenient but risky)</li>
                <li><strong>Cold Wallets:</strong> Offline storage (secure but less convenient)</li>
                <li><strong>Exchange Wallets:</strong> Stored on trading platforms</li>
            </ul>
        `
    },
    etfs: {
        title: 'ETF Investing Guide',
        content: `
            <h3>Understanding ETFs</h3>
            <p>Exchange-Traded Funds (ETFs) are investment funds that trade on stock exchanges, similar to individual stocks.</p>
            
            <h4>ETF Categories:</h4>
            <ul>
                <li><strong>Stock ETFs:</strong> Track stock market indices</li>
                <li><strong>Bond ETFs:</strong> Invest in fixed-income securities</li>
                <li><strong>Sector ETFs:</strong> Focus on specific industries</li>
                <li><strong>International ETFs:</strong> Invest in foreign markets</li>
                <li><strong>Commodity ETFs:</strong> Track commodity prices</li>
            </ul>
            
            <h4>Advantages of ETFs:</h4>
            <ul>
                <li>Low expense ratios</li>
                <li>High liquidity</li>
                <li>Tax efficiency</li>
                <li>Diversification</li>
                <li>Transparency</li>
            </ul>
            
            <h4>Popular ETFs:</h4>
            <ul>
                <li><strong>SPY:</strong> S&P 500 ETF</li>
                <li><strong>QQQ:</strong> NASDAQ-100 ETF</li>
                <li><strong>VTI:</strong> Total Stock Market ETF</li>
                <li><strong>BND:</strong> Total Bond Market ETF</li>
            </ul>
        `
    }
};

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    initializePortfolioChart();
    loadPortfolioFromAPI();
    loadMarketIndices();
    setupEventListeners();
});

// ... remaining logic unchanged from original ...

