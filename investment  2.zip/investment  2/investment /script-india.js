// API Base URL - Production-ready configuration
const API_BASE_URL = (() => {
    const hostname = window.location.hostname;
    const protocol = window.location.protocol;
    
    // Production deployments
    if (hostname.includes('vercel.app')) {
        return `${protocol}//${hostname}/api`;
    }
    
    if (hostname.includes('netlify.app')) {
        return `${protocol}//${hostname}/.netlify/functions/api`;
    }
    
    if (hostname.includes('github.io')) {
        // GitHub Pages - use static data only
        return null;
    }
    
    if (hostname.includes('railway.app') || hostname.includes('render.com') || hostname.includes('herokuapp.com')) {
        return `${protocol}//${hostname}/api`;
    }
    
    // Custom domain or other hosting
    if (hostname !== 'localhost' && hostname !== '127.0.0.1') {
        return `${protocol}//${hostname}/api`;
    }
    
    // Fallback to static mode
    return null;
})();

// Portfolio data will be loaded from backend
let portfolio = [];

// Investment guides content for Indian market
const guides = {
    stocks: {
        title: 'Indian Stock Market Investing Guide',
        content: `
            <h3>Understanding Indian Stock Market</h3>
            <p>The Indian stock market consists of two major exchanges: NSE (National Stock Exchange) and BSE (Bombay Stock Exchange). Stocks represent ownership in Indian companies.</p>
            
            <h4>Key Indian Market Concepts:</h4>
            <ul>
                <li><strong>NIFTY 50:</strong> Benchmark index of top 50 companies</li>
                <li><strong>SENSEX:</strong> BSE's 30-stock index</li>
                <li><strong>Market Cap:</strong> Total value in Indian Rupees</li>
                <li><strong>P/E Ratio:</strong> Price-to-Earnings ratio for valuation</li>
                <li><strong>Dividends:</strong> Regular payments to shareholders</li>
            </ul>
            
            <h4>Popular Indian Stocks:</h4>
            <ul>
                <li><strong>Reliance Industries:</strong> Oil, gas, and retail conglomerate</li>
                <li><strong>TCS:</strong> Leading IT services company</li>
                <li><strong>HDFC Bank:</strong> Top private sector bank</li>
                <li><strong>Infosys:</strong> Global IT services leader</li>
            </ul>
            
            <h4>Investment Strategies:</h4>
            <ul>
                <li><strong>Value Investing:</strong> Buy undervalued Indian stocks</li>
                <li><strong>Growth Investing:</strong> Focus on high-growth Indian companies</li>
                <li><strong>Dividend Investing:</strong> Invest in dividend-paying Indian stocks</li>
                <li><strong>Index Investing:</strong> Buy NIFTY/SENSEX ETFs</li>
            </ul>
        `
    },
    'mutual-funds': {
        title: 'Indian Mutual Funds Guide',
        content: `
            <h3>Understanding Indian Mutual Funds</h3>
            <p>Indian mutual funds pool money from investors to invest in Indian stocks, bonds, and other securities. Regulated by SEBI (Securities and Exchange Board of India).</p>
            
            <h4>Types of Indian Mutual Funds:</h4>
            <ul>
                <li><strong>Equity Funds:</strong> Invest in Indian stocks</li>
                <li><strong>Debt Funds:</strong> Invest in Indian bonds and fixed income</li>
                <li><strong>Hybrid Funds:</strong> Mix of Indian stocks and bonds</li>
                <li><strong>Index Funds:</strong> Track NIFTY, SENSEX indices</li>
                <li><strong>ELSS:</strong> Tax-saving equity funds (80C benefit)</li>
            </ul>
            
            <h4>Popular Indian Fund Houses:</h4>
            <ul>
                <li><strong>SBI Mutual Fund:</strong> Largest fund house in India</li>
                <li><strong>HDFC Mutual Fund:</strong> Leading private fund house</li>
                <li><strong>ICICI Prudential:</strong> Top performing funds</li>
                <li><strong>Axis Mutual Fund:</strong> Innovative fund solutions</li>
            </ul>
            
            <h4>Tax Benefits:</h4>
            <ul>
                <li>ELSS funds offer 80C tax deduction up to ₹1.5 lakh</li>
                <li>Long-term capital gains (>1 year) taxed at 10% above ₹1 lakh</li>
                <li>SIP investments help in rupee cost averaging</li>
            </ul>
        `
    },
    crypto: {
        title: 'Cryptocurrency in India Guide',
        content: `
            <h3>Cryptocurrency Trading in India</h3>
            <p>Cryptocurrency trading is legal in India with proper tax compliance. Popular Indian exchanges include WazirX, CoinDCX, and Zebpay.</p>
            
            <h4>Popular Cryptocurrencies in India:</h4>
            <ul>
                <li><strong>Bitcoin (BTC):</strong> Most traded crypto in India</li>
                <li><strong>Ethereum (ETH):</strong> Second most popular</li>
                <li><strong>Polygon (MATIC):</strong> Indian blockchain project</li>
                <li><strong>Cardano (ADA):</strong> Growing popularity</li>
            </ul>
            
            <h4>Indian Crypto Regulations:</h4>
            <ul>
                <li><strong>Legal Status:</strong> Legal to trade and hold</li>
                <li><strong>Taxation:</strong> 30% tax on crypto gains</li>
                <li><strong>TDS:</strong> 1% TDS on crypto transactions</li>
                <li><strong>Exchanges:</strong> Must comply with Indian regulations</li>
            </ul>
            
            <h4>Indian Crypto Exchanges:</h4>
            <ul>
                <li><strong>WazirX:</strong> Largest Indian crypto exchange</li>
                <li><strong>CoinDCX:</strong> Popular trading platform</li>
                <li><strong>Zebpay:</strong> Established Indian exchange</li>
                <li><strong>Bitbns:</strong> Growing Indian platform</li>
            </ul>
        `
    },
    etfs: {
        title: 'Indian ETF Investing Guide',
        content: `
            <h3>Understanding Indian ETFs</h3>
            <p>Exchange-Traded Funds (ETFs) in India track various indices like NIFTY 50, SENSEX, and sector-specific indices.</p>
            
            <h4>Popular Indian ETFs:</h4>
            <ul>
                <li><strong>NIFTY BeES:</strong> Tracks NIFTY 50 index</li>
                <li><strong>SBI ETF SENSEX:</strong> Tracks BSE SENSEX</li>
                <li><strong>HDFC NIFTY 50 ETF:</strong> Low-cost NIFTY tracking</li>
                <li><strong>ICICI Pru NIFTY ETF:</strong> Popular choice</li>
            </ul>
            
            <h4>Sector ETFs in India:</h4>
            <ul>
                <li><strong>Banking ETFs:</strong> Track banking sector</li>
                <li><strong>IT ETFs:</strong> Focus on IT companies</li>
                <li><strong>Pharma ETFs:</strong> Pharmaceutical sector</li>
                <li><strong>Auto ETFs:</strong> Automobile sector</li>
            </ul>
            
            <h4>Advantages for Indian Investors:</h4>
            <ul>
                <li>Low expense ratios (0.05% to 0.5%)</li>
                <li>High liquidity on NSE/BSE</li>
                <li>Tax efficiency compared to mutual funds</li>
                <li>Diversification across Indian markets</li>
                <li>Real-time trading during market hours</li>
            </ul>
        `
    }
};

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    initializePortfolioChart();
    initializeSectorChart();
    loadPortfolioFromAPI();
    loadMarketIndices();
    loadNews();
    setupEventListeners();
    setupCalculators();
});

// Setup event listeners
function setupEventListeners() {
    // Risk assessment form
    const riskForm = document.getElementById('riskForm');
    if (riskForm) {
        riskForm.addEventListener('submit', handleRiskAssessment);
    }

    // Investment form
    const investmentForm = document.getElementById('investmentForm');
    if (investmentForm) {
        investmentForm.addEventListener('submit', handleAddInvestment);
    }

    // Modal close button
    const closeBtn = document.querySelector('.close');
    if (closeBtn) {
        closeBtn.addEventListener('click', closeModal);
    }

    // Close modal when clicking outside
    window.addEventListener('click', function(event) {
        const modal = document.getElementById('investmentModal');
        if (event.target === modal) {
            closeModal();
        }
    });
}

// Portfolio Chart with Indian Rupees
function initializePortfolioChart() {
    const ctx = document.getElementById('portfolioChart');
    if (!ctx) return;

    const labels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
    const data = [500000, 525000, 550000, 540000, 575000, 627150]; // Values in INR

    new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Portfolio Value (₹)',
                data: data,
                borderColor: '#667eea',
                backgroundColor: 'rgba(102, 126, 234, 0.1)',
                borderWidth: 3,
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: false,
                    ticks: {
                        callback: function(value) {
                            return '₹' + value.toLocaleString('en-IN');
                        }
                    }
                }
            }
        }
    });
}

// Sector Chart for Indian Market
function initializeSectorChart() {
    const ctx = document.getElementById('sectorChart');
    if (!ctx) return;

    fetch(`${API_BASE_URL}/sectors`)
        .then(response => response.json())
        .then(data => {
            const sectors = Object.keys(data);
            const performance = sectors.map(sector => data[sector].performance);

            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: sectors,
                    datasets: [{
                        label: 'Sector Performance (%)',
                        data: performance,
                        backgroundColor: [
                            '#667eea',
                            '#764ba2',
                            '#f093fb',
                            '#f5576c',
                            '#4facfe',
                            '#43e97b'
                        ],
                        borderWidth: 0
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback: function(value) {
                                    return value + '%';
                                }
                            }
                        }
                    }
                }
            });
        })
        .catch(error => {
            console.error('Error loading sector data:', error);
            // Fallback data
            const fallbackData = {
                labels: ['IT', 'Banking', 'Oil & Gas', 'FMCG', 'Telecom', 'Auto'],
                datasets: [{
                    label: 'Sector Performance (%)',
                    data: [2.8, 1.2, 3.1, 0.9, 2.5, -0.8],
                    backgroundColor: ['#667eea', '#764ba2', '#f093fb', '#f5576c', '#4facfe', '#43e97b'],
                    borderWidth: 0
                }]
            };

            new Chart(ctx, {
                type: 'bar',
                data: fallbackData,
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { display: false } },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: { callback: function(value) { return value + '%'; } }
                        }
                    }
                }
            });
        });
}

// Load Indian Market Indices
async function loadMarketIndices() {
    try {
        const response = await fetch(`${API_BASE_URL}/indices`);
        if (!response.ok) throw new Error('API not available');
        
        const indices = await response.json();
        
        // Update dashboard cards with Indian market data
        updateDashboardCards(indices);
        updateMarketIndicesDisplay(indices);
        
        // Show backend connected status
        showNotification('✅ Connected to live market data', 'success');
    } catch (error) {
        console.warn('Backend not available, using static data:', error);
        
        // Use comprehensive fallback data
        const fallbackIndices = {
            'NIFTY50': { name: 'NIFTY 50', value: 19847.35, change: 156.80, changePercent: 0.80 },
            'SENSEX': { name: 'BSE SENSEX', value: 66589.93, change: 234.12, changePercent: 0.35 },
            'BANKNIFTY': { name: 'BANK NIFTY', value: 45234.67, change: -123.45, changePercent: -0.27 },
            'NIFTYIT': { name: 'NIFTY IT', value: 32456.78, change: 287.90, changePercent: 0.90 }
        };
        updateMarketIndicesDisplay(fallbackIndices);
        
        // Show fallback mode notification
        showNotification('📊 Using demo data (backend offline)', 'info');
    }
}

// Update market indices display
function updateMarketIndicesDisplay(indices) {
    const indicesContainer = document.querySelector('.indices-grid');
    if (!indicesContainer) return;

    indicesContainer.innerHTML = Object.entries(indices).map(([key, data]) => `
        <div class="index-card">
            <h4>${data.name}</h4>
            <p class="index-value">${data.value.toLocaleString('en-IN', {minimumFractionDigits: 2})}</p>
            <p class="change ${data.change >= 0 ? 'positive' : 'negative'}">
                ${data.change >= 0 ? '+' : ''}${data.change.toFixed(2)} (${data.changePercent.toFixed(2)}%)
            </p>
        </div>
    `).join('');
}

// Update dashboard cards with portfolio data
function updateDashboardCards(indices) {
    // Calculate total portfolio value from current portfolio
    let totalValue = 0;
    let totalInvested = 0;
    
    portfolio.forEach(investment => {
        totalValue += investment.currentValue || 0;
        totalInvested += investment.investedValue || 0;
    });
    
    const totalGain = totalValue - totalInvested;
    const totalGainPercent = totalInvested > 0 ? ((totalGain / totalInvested) * 100) : 0;
    
    // Update portfolio value card
    const portfolioValueCard = document.querySelector('.dashboard-grid .card:first-child');
    if (portfolioValueCard) {
        portfolioValueCard.innerHTML = `
            <h3>Portfolio Value</h3>
            <p class="value">₹${totalValue.toLocaleString('en-IN')}</p>
            <p class="change ${totalGain >= 0 ? 'positive' : 'negative'}">
                ${totalGain >= 0 ? '+' : ''}₹${Math.abs(totalGain).toLocaleString('en-IN')} (${totalGainPercent.toFixed(1)}%)
            </p>
        `;
    }
}

// Load portfolio from API
async function loadPortfolioFromAPI() {
    try {
        const response = await fetch(`${API_BASE_URL}/portfolio`);
        if (!response.ok) throw new Error('API not available');
        
        portfolio = await response.json();
        loadPortfolio();
        updateDashboardCards();
    } catch (error) {
        console.warn('Portfolio API not available, using demo data:', error);
        
        // Use comprehensive fallback data
        portfolio = [
            {
                id: 1,
                symbol: 'RELIANCE',
                stockName: 'Reliance Industries Ltd',
                quantity: 50,
                purchasePrice: 2200.00,
                currentPrice: 2456.75,
                currentValue: 122837.50,
                investedValue: 110000.00,
                gainLoss: 12837.50,
                gainLossPercent: 11.67
            },
            {
                id: 2,
                symbol: 'TCS',
                stockName: 'Tata Consultancy Services',
                quantity: 25,
                purchasePrice: 3600.00,
                currentPrice: 3789.20,
                currentValue: 94730.00,
                investedValue: 90000.00,
                gainLoss: 4730.00,
                gainLossPercent: 5.26
            },
            {
                id: 3,
                symbol: 'HDFCBANK',
                stockName: 'HDFC Bank Ltd',
                quantity: 75,
                purchasePrice: 1580.00,
                currentPrice: 1634.85,
                currentValue: 122613.75,
                investedValue: 118500.00,
                gainLoss: 4113.75,
                gainLossPercent: 3.47
            },
            {
                id: 4,
                symbol: 'INFY',
                stockName: 'Infosys Ltd',
                quantity: 100,
                purchasePrice: 1400.00,
                currentPrice: 1456.30,
                currentValue: 145630.00,
                investedValue: 140000.00,
                gainLoss: 5630.00,
                gainLossPercent: 4.02
            }
        ];
        loadPortfolio();
        updateDashboardCards();
    }
}

// Load portfolio data and display
function loadPortfolio() {
    const tbody = document.getElementById('portfolioBody');
    if (!tbody) return;

    tbody.innerHTML = '';
    
    portfolio.forEach(investment => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td><strong>${investment.stockName || investment.symbol}</strong><br><small>${investment.symbol}</small></td>
            <td><span class="badge badge-stock">STOCK</span></td>
            <td>${investment.quantity}</td>
            <td>₹${investment.currentPrice.toLocaleString('en-IN', {minimumFractionDigits: 2})}</td>
            <td>₹${investment.currentValue.toLocaleString('en-IN')}</td>
            <td class="${investment.gainLoss >= 0 ? 'positive' : 'negative'}">
                ${investment.gainLoss >= 0 ? '+' : ''}₹${Math.abs(investment.gainLoss).toLocaleString('en-IN')} (${investment.gainLossPercent.toFixed(2)}%)
            </td>
            <td>
                <button class="btn btn-small" onclick="editInvestment(${investment.id})">Edit</button>
                <button class="btn btn-small btn-danger" onclick="deleteInvestment(${investment.id})">Delete</button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

// Load and display Indian financial news
async function loadNews(filter = 'all') {
    try {
        const url = filter === 'all' ? `${API_BASE_URL}/news` : `${API_BASE_URL}/news?category=${filter}`;
        const response = await fetch(url);
        const newsData = await response.json();
        
        const newsGrid = document.getElementById('newsGrid');
        if (!newsGrid) return;

        newsGrid.innerHTML = newsData.map(item => `
            <div class="news-item" data-category="${item.category}">
                <div class="news-meta">
                    <span class="news-category">${item.category.toUpperCase()}</span>
                    <span class="news-time">${item.time}</span>
                </div>
                <h4>${item.title}</h4>
                <p>${item.summary}</p>
                <small class="news-source">Source: ${item.source}</small>
            </div>
        `).join('');
    } catch (error) {
        console.error('Error loading news:', error);
        // Fallback to static news data
        loadStaticNews(filter);
    }
}

// Fallback static news data
function loadStaticNews(filter = 'all') {
    const staticNews = [
        {
            title: "NIFTY 50 Hits New All-Time High, Crosses 20,000 Mark",
            summary: "Indian benchmark index reaches historic milestone driven by strong corporate earnings and positive FII sentiment.",
            category: "markets",
            time: "2 hours ago",
            source: "Economic Times"
        },
        {
            title: "Reliance Industries Reports Strong Q3 Results",
            summary: "India's largest private company beats estimates with robust performance across petrochemicals and retail.",
            category: "stocks",
            time: "4 hours ago",
            source: "Business Standard"
        }
    ];

    const newsGrid = document.getElementById('newsGrid');
    if (!newsGrid) return;

    const filteredNews = filter === 'all' ? staticNews : staticNews.filter(item => item.category === filter);
    
    newsGrid.innerHTML = filteredNews.map(item => `
        <div class="news-item">
            <div class="news-meta">
                <span class="news-category">${item.category.toUpperCase()}</span>
                <span class="news-time">${item.time}</span>
            </div>
            <h4>${item.title}</h4>
            <p>${item.summary}</p>
            <small class="news-source">Source: ${item.source}</small>
        </div>
    `).join('');
}

// Filter news by category
function filterNews(category) {
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    event.target.classList.add('active');
    
    loadNews(category);
}

// Add investment modal
function addInvestment() {
    const modal = document.getElementById('investmentModal');
    modal.style.display = 'flex';
}

// Close modal
function closeModal() {
    const modal = document.getElementById('investmentModal');
    modal.style.display = 'none';
}

// Handle add investment form
async function handleAddInvestment(event) {
    event.preventDefault();
    
    const formData = new FormData(event.target);
    const investmentData = {
        symbol: formData.get('assetName').toUpperCase(),
        quantity: parseFloat(formData.get('quantity')),
        purchasePrice: parseFloat(formData.get('purchasePrice'))
    };
    
    try {
        const response = await fetch(`${API_BASE_URL}/portfolio`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(investmentData)
        });
        
        if (response.ok) {
            await loadPortfolioFromAPI();
            closeModal();
            event.target.reset();
            showNotification('Investment added successfully!', 'success');
        } else {
            const error = await response.json();
            showNotification(error.error || 'Failed to add investment', 'error');
        }
    } catch (error) {
        console.error('Error adding investment:', error);
        showNotification('Failed to add investment', 'error');
    }
}

// Edit investment
async function editInvestment(id) {
    const investment = portfolio.find(inv => inv.id === id);
    if (!investment) return;
    
    const newPrice = prompt(`Enter new purchase price for ${investment.stockName}:`, investment.purchasePrice);
    if (newPrice && !isNaN(newPrice)) {
        try {
            const response = await fetch(`${API_BASE_URL}/portfolio/${id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ purchasePrice: parseFloat(newPrice) })
            });
            
            if (response.ok) {
                await loadPortfolioFromAPI();
                showNotification('Investment updated successfully!', 'success');
            }
        } catch (error) {
            console.error('Error updating investment:', error);
            showNotification('Failed to update investment', 'error');
        }
    }
}

// Delete investment
async function deleteInvestment(id) {
    if (confirm('Are you sure you want to delete this investment?')) {
        try {
            const response = await fetch(`${API_BASE_URL}/portfolio/${id}`, {
                method: 'DELETE'
            });
            
            if (response.ok) {
                await loadPortfolioFromAPI();
                showNotification('Investment deleted successfully!', 'success');
            }
        } catch (error) {
            console.error('Error deleting investment:', error);
            showNotification('Failed to delete investment', 'error');
        }
    }
}

// Refresh portfolio data
async function refreshData() {
    showLoading('portfolioBody');
    
    try {
        await loadPortfolioFromAPI();
        await loadMarketIndices();
        showNotification('Portfolio data refreshed!', 'info');
    } catch (error) {
        console.error('Error refreshing data:', error);
        showNotification('Failed to refresh data', 'error');
    }
}

// Show investment guide
function showGuide(type) {
    const guide = guides[type];
    if (!guide) return;
    
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.style.display = 'flex';
    
    modal.innerHTML = `
        <div class="modal-content" style="max-width: 800px; max-height: 80vh; overflow-y: auto;">
            <span class="close" onclick="this.parentElement.parentElement.remove()">&times;</span>
            <h2>${guide.title}</h2>
            <div class="guide-content">
                ${guide.content}
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    modal.addEventListener('click', function(event) {
        if (event.target === modal) {
            modal.remove();
        }
    });
}

// Calculator functions (updated for Indian Rupees)
function setupCalculators() {
    const calculatorInputs = document.querySelectorAll('#compound-calculator input');
    calculatorInputs.forEach(input => {
        input.addEventListener('input', calculateCompound);
    });
}

function showCalculator(type) {
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    event.target.classList.add('active');
    
    document.querySelectorAll('.calculator-content').forEach(content => {
        content.classList.remove('active');
    });
    document.getElementById(`${type}-calculator`).classList.add('active');
}

function calculateCompound() {
    const initialAmount = parseFloat(document.getElementById('initialAmount')?.value) || 0;
    const monthlyContribution = parseFloat(document.getElementById('monthlyContribution')?.value) || 0;
    const annualRate = parseFloat(document.getElementById('interestRate')?.value) || 0;
    const years = parseFloat(document.getElementById('investmentYears')?.value) || 0;
    
    if (years === 0) return;
    
    const monthlyRate = annualRate / 100 / 12;
    const totalMonths = years * 12;
    
    const futureValueInitial = initialAmount * Math.pow(1 + monthlyRate, totalMonths);
    const futureValueContributions = monthlyContribution * 
        ((Math.pow(1 + monthlyRate, totalMonths) - 1) / monthlyRate);
    
    const totalValue = futureValueInitial + futureValueContributions;
    const totalContributions = initialAmount + (monthlyContribution * totalMonths);
    const totalInterest = totalValue - totalContributions;
    
    const resultsDiv = document.getElementById('compoundResults');
    if (resultsDiv) {
        resultsDiv.innerHTML = `
            <div class="result-item">
                <div class="result-value">₹${totalValue.toLocaleString('en-IN', {maximumFractionDigits: 0})}</div>
                <div class="result-label">Final Amount</div>
            </div>
            <div class="result-item">
                <div class="result-value">₹${totalContributions.toLocaleString('en-IN', {maximumFractionDigits: 0})}</div>
                <div class="result-label">Total Contributions</div>
            </div>
            <div class="result-item">
                <div class="result-value">₹${totalInterest.toLocaleString('en-IN', {maximumFractionDigits: 0})}</div>
                <div class="result-label">Interest Earned</div>
            </div>
        `;
    }
}

// Risk assessment with Indian context
function handleRiskAssessment(event) {
    event.preventDefault();
    
    const formData = new FormData(event.target);
    const timeHorizon = parseInt(formData.get('timeHorizon'));
    const riskReaction = parseInt(formData.get('riskReaction'));
    const savingsRate = parseInt(formData.get('savingsRate'));
    
    const riskScore = Math.round((timeHorizon + riskReaction + savingsRate) / 3);
    
    let riskLevel, recommendations;
    
    if (riskScore <= 3) {
        riskLevel = 'Conservative';
        recommendations = [
            'Focus on Indian government bonds and fixed deposits',
            'Consider high-quality dividend stocks like ITC, HDFC Bank',
            'Invest in debt mutual funds and ELSS for tax benefits',
            'Avoid speculative stocks and crypto investments'
        ];
    } else if (riskScore <= 6) {
        riskLevel = 'Moderate';
        recommendations = [
            'Balance between Indian equity and debt funds',
            'Consider NIFTY 50 index funds for diversification',
            'Regular SIP in large-cap mutual funds',
            'Moderate exposure to mid-cap Indian stocks'
        ];
    } else {
        riskLevel = 'Aggressive';
        recommendations = [
            'Higher allocation to Indian growth stocks and small-cap funds',
            'Consider sectoral ETFs (IT, Banking, Pharma)',
            'Explore international funds for global diversification',
            'Regular monitoring of portfolio performance'
        ];
    }
    
    document.getElementById('riskScore').textContent = riskScore;
    document.getElementById('riskLevel').textContent = riskLevel;
    
    const recommendationsList = document.getElementById('recommendations');
    recommendationsList.innerHTML = `
        <h4>Recommended Strategy for Indian Markets:</h4>
        <ul>
            ${recommendations.map(rec => `<li>${rec}</li>`).join('')}
        </ul>
    `;
    
    document.getElementById('riskResults').style.display = 'block';
    document.getElementById('riskResults').scrollIntoView({ behavior: 'smooth' });
}

// Utility functions
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 1rem 1.5rem;
        border-radius: 8px;
        color: white;
        font-weight: 500;
        z-index: 1002;
        animation: slideIn 0.3s ease;
    `;
    
    if (type === 'success') {
        notification.style.background = '#10b981';
    } else if (type === 'error') {
        notification.style.background = '#ef4444';
    } else {
        notification.style.background = '#3b82f6';
    }
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.remove();
    }, 3000);
}

function showLoading(elementId) {
    const element = document.getElementById(elementId);
    if (element) {
        element.innerHTML = '<div class="loading"></div>';
    }
}

// Theme toggle
function toggleTheme() {
    document.body.classList.toggle('dark-theme');
    const themeBtn = document.querySelector('.nav-actions .btn-outline');
    if (themeBtn) {
        themeBtn.textContent = document.body.classList.contains('dark-theme') ? '☀️' : '🌙';
    }
    localStorage.setItem('theme', document.body.classList.contains('dark-theme') ? 'dark' : 'light');
}

// Load saved theme
function loadTheme() {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark') {
        document.body.classList.add('dark-theme');
        const themeBtn = document.querySelector('.nav-actions .btn-outline');
        if (themeBtn) {
            themeBtn.textContent = '☀️';
        }
    }
}

// Enhanced setup
document.addEventListener('DOMContentLoaded', function() {
    loadTheme();
    setTimeout(calculateCompound, 100);
});

// Smooth scrolling for navigation links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});// Teleg
ram Integration Functions

// Telegram channels data
const telegramChannels = {
    main: {
        name: 'Finance Wizards - Main Channel',
        url: 'https://t.me/financewizards_main',
        description: 'Daily market updates and stock recommendations'
    },
    alerts: {
        name: 'FW - Quick Alerts',
        url: 'https://t.me/financewizards_alerts',
        description: 'Instant price alerts and breaking news'
    },
    education: {
        name: 'FW - Learning Hub',
        url: 'https://t.me/financewizards_education',
        description: 'Educational content and trading strategies'
    },
    premium: {
        name: 'FW - Premium Signals',
        url: 'https://t.me/financewizards_premium',
        description: 'Exclusive trading signals and portfolio tips'
    }
};

// Sample Telegram news feed data
const telegramNewsData = [
    {
        id: 1,
        channel: 'Finance Wizards - Main',
        content: '🚀 RELIANCE breaks above ₹2,500! Strong momentum with volume spike. Target: ₹2,650. Stop Loss: ₹2,420.',
        time: '2 minutes ago',
        tags: ['RELIANCE', 'Breakout', 'Buy Signal']
    },
    {
        id: 2,
        channel: 'FW - Quick Alerts',
        content: '⚡ NIFTY 50 hits new ATH at 20,150! Banking stocks leading the rally. HDFC Bank +3.2%, ICICI Bank +2.8%.',
        time: '15 minutes ago',
        tags: ['NIFTY50', 'ATH', 'Banking']
    },
    {
        id: 3,
        channel: 'Finance Wizards - Main',
        content: '📊 Market Analysis: IT sector showing strength. TCS, Infosys, HCL Tech all in green. Good time for IT portfolio allocation.',
        time: '1 hour ago',
        tags: ['IT Sector', 'Analysis', 'Portfolio']
    },
    {
        id: 4,
        channel: 'FW - Learning Hub',
        content: '🎓 Trading Tip: Always use stop-loss orders. Risk management is more important than profit maximization. Protect your capital first!',
        time: '2 hours ago',
        tags: ['Education', 'Risk Management', 'Tips']
    },
    {
        id: 5,
        channel: 'FW - Premium Signals',
        content: '💎 Premium Alert: HDFC Bank showing bullish divergence on RSI. Entry: ₹1,635, Target: ₹1,720, SL: ₹1,580.',
        time: '3 hours ago',
        tags: ['HDFCBANK', 'Premium', 'Technical Analysis']
    }
];

// Join Telegram channel function
function joinTelegramChannel(channelType) {
    const channel = telegramChannels[channelType];
    if (channel) {
        // In a real implementation, this would open the Telegram channel
        showNotification(`Opening ${channel.name}...`, 'info');
        
        // Simulate opening Telegram (in real app, this would open the actual Telegram link)
        setTimeout(() => {
            showNotification(`Welcome to ${channel.name}! 🎉`, 'success');
        }, 1000);
        
        // Track user interaction
        trackTelegramJoin(channelType);
    }
}

// Track Telegram channel joins
function trackTelegramJoin(channelType) {
    // Store user preferences
    const userPreferences = JSON.parse(localStorage.getItem('telegramPreferences') || '{}');
    userPreferences.joinedChannels = userPreferences.joinedChannels || [];
    
    if (!userPreferences.joinedChannels.includes(channelType)) {
        userPreferences.joinedChannels.push(channelType);
        userPreferences.joinDate = new Date().toISOString();
        localStorage.setItem('telegramPreferences', JSON.stringify(userPreferences));
    }
}

// Handle Telegram signup form
function setupTelegramForm() {
    const telegramForm = document.getElementById('telegramSignupForm');
    if (telegramForm) {
        telegramForm.addEventListener('submit', function(event) {
            event.preventDefault();
            
            const formData = new FormData(event.target);
            const telegramData = {
                username: formData.get('telegramUsername'),
                phone: formData.get('phoneNumber'),
                stocks: formData.getAll('stocks'),
                alertType: formData.get('alertType')
            };
            
            // Validate Telegram username
            if (!telegramData.username.startsWith('@')) {
                showNotification('Please enter a valid Telegram username starting with @', 'error');
                return;
            }
            
            // Store user preferences
            localStorage.setItem('telegramAlerts', JSON.stringify(telegramData));
            
            // Simulate API call to backend
            setTimeout(() => {
                showNotification('Successfully subscribed to Telegram alerts! 🎉', 'success');
                event.target.reset();
                
                // Show confirmation message
                showTelegramConfirmation(telegramData);
            }, 1000);
        });
    }
}

// Show Telegram subscription confirmation
function showTelegramConfirmation(data) {
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.style.display = 'flex';
    
    modal.innerHTML = `
        <div class="modal-content" style="max-width: 500px;">
            <span class="close" onclick="this.parentElement.parentElement.remove()">&times;</span>
            <h2>🎉 Telegram Alerts Activated!</h2>
            <div style="text-align: center; margin: 2rem 0;">
                <div style="font-size: 4rem; margin-bottom: 1rem;">📱</div>
                <h3>Welcome to Finance Wizards Telegram Network!</h3>
                <p>You'll receive alerts for: <strong>${data.stocks.join(', ')}</strong></p>
                <p>Alert type: <strong>${data.alertType.replace('_', ' ').toUpperCase()}</strong></p>
            </div>
            <div style="background: #f8fafc; padding: 1rem; border-radius: 10px; margin: 1rem 0;">
                <h4>What's Next?</h4>
                <ul style="text-align: left; margin: 1rem 0;">
                    <li>✅ Check your Telegram for a welcome message</li>
                    <li>📱 Enable notifications for instant alerts</li>
                    <li>🔔 Customize your alert preferences anytime</li>
                    <li>💬 Join our community discussions</li>
                </ul>
            </div>
            <button class="btn btn-primary" onclick="this.parentElement.parentElement.remove()">
                Got it! 🚀
            </button>
        </div>
    `;
    
    document.body.appendChild(modal);
}

// Load Telegram news feed
function loadTelegramNewsFeed() {
    const newsFeed = document.getElementById('telegramNewsFeed');
    if (!newsFeed) return;
    
    newsFeed.innerHTML = telegramNewsData.map(item => `
        <div class="telegram-news-item">
            <div class="telegram-news-header">
                <span class="telegram-channel-name">${item.channel}</span>
                <span class="telegram-news-time">${item.time}</span>
            </div>
            <div class="telegram-news-content">${item.content}</div>
            <div class="telegram-news-tags">
                ${item.tags.map(tag => `<span class="telegram-tag">${tag}</span>`).join('')}
            </div>
        </div>
    `).join('');
}

// Add Telegram bot widget
function addTelegramBotWidget() {
    const widget = document.createElement('div');
    widget.className = 'telegram-bot-widget';
    widget.innerHTML = `
        <div class="bot-icon">💬</div>
    `;
    
    widget.addEventListener('click', function() {
        showTelegramBotChat();
    });
    
    document.body.appendChild(widget);
}

// Show Telegram bot chat interface
function showTelegramBotChat() {
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.style.display = 'flex';
    
    modal.innerHTML = `
        <div class="modal-content" style="max-width: 400px; height: 500px;">
            <span class="close" onclick="this.parentElement.parentElement.remove()">&times;</span>
            <h3>🤖 Finance Wizards Bot</h3>
            <div style="height: 300px; overflow-y: auto; background: #f8fafc; padding: 1rem; border-radius: 10px; margin: 1rem 0;">
                <div style="margin-bottom: 1rem;">
                    <strong>Bot:</strong> Hi! I'm the Finance Wizards bot. How can I help you today?
                </div>
                <div style="margin-bottom: 1rem;">
                    <strong>Available Commands:</strong><br>
                    📊 /price RELIANCE - Get current price<br>
                    📈 /alerts - Manage your alerts<br>
                    📰 /news - Latest market news<br>
                    🎯 /signals - Trading signals<br>
                    ❓ /help - Show all commands
                </div>
            </div>
            <div style="display: flex; gap: 0.5rem;">
                <input type="text" placeholder="Type a message..." style="flex: 1; padding: 0.5rem; border: 1px solid #ccc; border-radius: 5px;">
                <button class="btn btn-primary" style="padding: 0.5rem 1rem;">Send</button>
            </div>
            <div style="text-align: center; margin-top: 1rem;">
                <button class="btn btn-outline" onclick="window.open('https://t.me/financewizards_bot', '_blank')">
                    Open in Telegram
                </button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
}

// Collect user data for Telegram integration
async function collectTelegramData() {
    try {
        // Collect user interaction data
        const userData = {
            visitTime: new Date().toISOString(),
            userAgent: navigator.userAgent,
            screenResolution: `${screen.width}x${screen.height}`,
            timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
            language: navigator.language,
            referrer: document.referrer,
            currentPage: window.location.href
        };
        
        // Store locally (in real app, send to backend)
        const existingData = JSON.parse(localStorage.getItem('userAnalytics') || '[]');
        existingData.push(userData);
        
        // Keep only last 100 entries
        if (existingData.length > 100) {
            existingData.splice(0, existingData.length - 100);
        }
        
        localStorage.setItem('userAnalytics', JSON.stringify(existingData));
        
        // Send to backend API if available
        if (API_BASE_URL) {
            try {
                await fetch(`${API_BASE_URL}/analytics`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(userData)
                });
            } catch (error) {
                console.log('Analytics API not available:', error);
            }
        }
        
    } catch (error) {
        console.log('Error collecting user data:', error);
    }
}

// Initialize Telegram features
function initializeTelegramFeatures() {
    setupTelegramForm();
    loadTelegramNewsFeed();
    addTelegramBotWidget();
    collectTelegramData();
    
    // Auto-refresh news feed every 5 minutes
    setInterval(loadTelegramNewsFeed, 5 * 60 * 1000);
}

// Enhanced setup with Telegram features
document.addEventListener('DOMContentLoaded', function() {
    // Existing initialization
    loadTheme();
    setupContactForm();
    setupNewsletterForm();
    
    // New Telegram initialization
    initializeTelegramFeatures();
    
    setTimeout(calculateCompound, 100);
});

// Add Telegram data collection to existing functions
const originalShowNotification = showNotification;
showNotification = function(message, type = 'info') {
    // Track notification events
    const notificationData = {
        message: message,
        type: type,
        timestamp: new Date().toISOString()
    };
    
    const notifications = JSON.parse(localStorage.getItem('notificationHistory') || '[]');
    notifications.push(notificationData);
    
    // Keep only last 50 notifications
    if (notifications.length > 50) {
        notifications.splice(0, notifications.length - 50);
    }
    
    localStorage.setItem('notificationHistory', JSON.stringify(notifications));
    
    // Call original function
    originalShowNotification(message, type);
};