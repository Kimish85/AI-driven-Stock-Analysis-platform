import os
from datetime import datetime
from flask import Flask, jsonify, request, send_from_directory


def create_app() -> Flask:
    app = Flask(__name__, static_folder="static", template_folder="templates")

    # In-memory demo data for portfolio
    portfolio = [
        {
            "id": 1,
            "symbol": "RELIANCE",
            "stockName": "Reliance Industries Ltd",
            "quantity": 50,
            "purchasePrice": 2200.00,
            "currentPrice": 2456.75,
            "currentValue": 122837.50,
            "investedValue": 110000.00,
            "gainLoss": 12837.50,
            "gainLossPercent": 11.67,
        },
        {
            "id": 2,
            "symbol": "TCS",
            "stockName": "Tata Consultancy Services",
            "quantity": 25,
            "purchasePrice": 3600.00,
            "currentPrice": 3789.20,
            "currentValue": 94730.00,
            "investedValue": 90000.00,
            "gainLoss": 4730.00,
            "gainLossPercent": 5.26,
        },
    ]

    def next_id() -> int:
        return (max((p["id"] for p in portfolio), default=0) + 1)

    @app.get("/")
    def index():
        # Serve existing root index.html for now
        return send_from_directory(".", "index.html")

    # Map legacy asset paths to Flask static directory
    @app.get("/styles.css")
    def styles_css():
        return send_from_directory(app.static_folder, "styles.css")

    @app.get("/script.js")
    def script_js():
        return send_from_directory(app.static_folder, "script.js")

    @app.get("/script-india.js")
    def script_india_js():
        return send_from_directory(app.static_folder, "script-india.js")

    @app.get("/config.js")
    def config_js():
        return send_from_directory(app.static_folder, "config.js")

    @app.get("/healthz")
    def healthz():
        return jsonify({"status": "ok", "time": datetime.utcnow().isoformat() + "Z"})

    # API endpoints expected by the frontend
    @app.get("/api/indices")
    def api_indices():
        data = {
            "NIFTY50": {"name": "NIFTY 50", "value": 19847.35, "change": 156.80, "changePercent": 0.80},
            "SENSEX": {"name": "BSE SENSEX", "value": 66589.93, "change": 234.12, "changePercent": 0.35},
            "BANKNIFTY": {"name": "BANK NIFTY", "value": 45234.67, "change": -123.45, "changePercent": -0.27},
            "NIFTYIT": {"name": "NIFTY IT", "value": 32456.78, "change": 287.90, "changePercent": 0.90},
        }
        return jsonify(data)

    @app.get("/api/sectors")
    def api_sectors():
        data = {
            "IT": {"performance": 2.8},
            "Banking": {"performance": 1.2},
            "Oil & Gas": {"performance": 3.1},
            "FMCG": {"performance": 0.9},
            "Telecom": {"performance": 2.5},
            "Auto": {"performance": -0.8},
        }
        return jsonify(data)

    @app.get("/api/news")
    def api_news():
        category = request.args.get("category", "all")
        items = [
            {
                "title": "NIFTY 50 Hits New All-Time High, Crosses 20,000 Mark",
                "summary": "Indian benchmark index reaches historic milestone driven by strong corporate earnings and positive FII sentiment.",
                "category": "markets",
                "time": "2 hours ago",
                "source": "Economic Times",
            },
            {
                "title": "Reliance Industries Reports Strong Q3 Results",
                "summary": "India's largest private company beats estimates with robust performance across petrochemicals and retail.",
                "category": "stocks",
                "time": "4 hours ago",
                "source": "Business Standard",
            },
        ]
        if category != "all":
            items = [i for i in items if i["category"] == category]
        return jsonify(items)

    @app.get("/api/portfolio")
    def api_portfolio_list():
        return jsonify(portfolio)

    @app.post("/api/portfolio")
    def api_portfolio_create():
        payload = request.get_json(silent=True) or {}
        symbol = str(payload.get("symbol", "")).upper()
        quantity = float(payload.get("quantity", 0))
        purchase_price = float(payload.get("purchasePrice", 0))
        if not symbol or quantity <= 0 or purchase_price <= 0:
            return jsonify({"error": "Invalid input"}), 400
        item = {
            "id": next_id(),
            "symbol": symbol,
            "stockName": symbol,
            "quantity": quantity,
            "purchasePrice": purchase_price,
            "currentPrice": purchase_price,
            "currentValue": round(quantity * purchase_price, 2),
            "investedValue": round(quantity * purchase_price, 2),
            "gainLoss": 0.0,
            "gainLossPercent": 0.0,
        }
        portfolio.append(item)
        return jsonify(item), 201

    @app.put("/api/portfolio/<int:item_id>")
    def api_portfolio_update(item_id: int):
        payload = request.get_json(silent=True) or {}
        item = next((p for p in portfolio if p["id"] == item_id), None)
        if not item:
            return jsonify({"error": "Not found"}), 404
        if "purchasePrice" in payload:
            try:
                new_price = float(payload["purchasePrice"])
                item["purchasePrice"] = new_price
                item["currentPrice"] = max(item.get("currentPrice", new_price), new_price)
                item["investedValue"] = round(item["quantity"] * item["purchasePrice"], 2)
                item["currentValue"] = round(item["quantity"] * item["currentPrice"], 2)
                item["gainLoss"] = round(item["currentValue"] - item["investedValue"], 2)
                item["gainLossPercent"] = (item["gainLoss"] / item["investedValue"]) * 100 if item["investedValue"] else 0.0
            except Exception:
                return jsonify({"error": "Invalid purchasePrice"}), 400
        return jsonify(item)

    @app.delete("/api/portfolio/<int:item_id>")
    def api_portfolio_delete(item_id: int):
        nonlocal portfolio
        before = len(portfolio)
        portfolio = [p for p in portfolio if p["id"] != item_id]
        if len(portfolio) == before:
            return jsonify({"error": "Not found"}), 404
        return ("", 204)

    @app.post("/api/analytics")
    def api_analytics():
        # Accept any analytics payload
        _ = request.get_json(silent=True)
        return ("", 204)

    return app


app = create_app()

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=True)


