// API Base URL
const API_BASE_URL = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1' 
    ? 'http://localhost:3000/api' 
    : '/api';

// Portfolio data will be loaded from backend
let portfolio = [];

// Investment guides content
const guides = {
    stocks: {
        title: 'Stock Investing Guide',
        content: `
            <h3>Understanding Stock Investing</h3>
            <p>Stocks represent ownership in a company. When you buy a stock, you're purchasing a small piece of that company, called a share.</p>
            
            <h4>Key Concepts:</h4>
            <ul>
                <li><strong>Market Cap:</strong> Total value of all company shares</li>
                <li><strong>P/E Ratio:</strong> Price-to-Earnings ratio indicates valuation</li>
                <li><strong>Dividends:</strong> Regular payments to shareholders</li>
                <li><strong>Volatility:</strong> Price fluctuations over time</li>
            </ul>
            
            <h4>Investment Strategies:</h4>
            <ul>
                <li><strong>Value Investing:</strong> Buy undervalued stocks</li>
                <li><strong>Growth Investing:</strong> Focus on high-growth companies</li>
                <li><strong>Dividend Investing:</strong> Invest in dividend-paying stocks</li>
                <li><strong>Index Investing:</strong> Buy broad market ETFs</li>
            </ul>
            
            <h4>Risk Management:</h4>
            <ul>
                <li>Diversify across different sectors</li>
                <li>Don't invest more than you can afford to lose</li>
                <li>Consider your time horizon</li>
                <li>Regular portfolio rebalancing</li>
            </ul>
        `
    },
    'mutual-funds': {
        title: 'Mutual Funds Guide',
        content: `
            <h3>Understanding Mutual Funds</h3>
            <p>Mutual funds pool money from multiple investors to invest in a diversified portfolio of stocks, bonds, or other securities.</p>
            
            <h4>Types of Mutual Funds:</h4>
            <ul>
                <li><strong>Stock Funds:</strong> Invest primarily in stocks</li>
                <li><strong>Bond Funds:</strong> Invest in government and corporate bonds</li>
                <li><strong>Balanced Funds:</strong> Mix of stocks and bonds</li>
                <li><strong>Index Funds:</strong> Track specific market indices</li>
            </ul>
            
            <h4>Key Metrics:</h4>
            <ul>
                <li><strong>Expense Ratio:</strong> Annual fee as percentage of assets</li>
                <li><strong>Load:</strong> Sales commission (avoid no-load funds)</li>
                <li><strong>NAV:</strong> Net Asset Value per share</li>
                <li><strong>Performance:</strong> Historical returns</li>
            </ul>
            
            <h4>Advantages:</h4>
            <ul>
                <li>Professional management</li>
                <li>Instant diversification</li>
                <li>Accessibility for small investors</li>
                <li>Liquidity</li>
            </ul>
        `
    },
    crypto: {
        title: 'Cryptocurrency Guide',
        content: `
            <h3>Understanding Cryptocurrency</h3>
            <p>Cryptocurrencies are digital or virtual currencies that use cryptography for security and operate on decentralized networks.</p>
            
            <h4>Popular Cryptocurrencies:</h4>
            <ul>
                <li><strong>Bitcoin (BTC):</strong> First and most well-known cryptocurrency</li>
                <li><strong>Ethereum (ETH):</strong> Platform for smart contracts and dApps</li>
                <li><strong>Cardano (ADA):</strong> Research-driven blockchain platform</li>
                <li><strong>Solana (SOL):</strong> High-performance blockchain</li>
            </ul>
            
            <h4>Investment Considerations:</h4>
            <ul>
                <li><strong>Volatility:</strong> Extreme price fluctuations</li>
                <li><strong>Regulation:</strong> Evolving regulatory environment</li>
                <li><strong>Technology Risk:</strong> New and unproven technology</li>
                <li><strong>Security:</strong> Risk of hacking and fraud</li>
            </ul>
            
            <h4>Storage Options:</h4>
            <ul>
                <li><strong>Hot Wallets:</strong> Online storage (convenient but risky)</li>
                <li><strong>Cold Wallets:</strong> Offline storage (secure but less convenient)</li>
                <li><strong>Exchange Wallets:</strong> Stored on trading platforms</li>
            </ul>
        `
    },
    etfs: {
        title: 'ETF Investing Guide',
        content: `
            <h3>Understanding ETFs</h3>
            <p>Exchange-Traded Funds (ETFs) are investment funds that trade on stock exchanges, similar to individual stocks.</p>
            
            <h4>ETF Categories:</h4>
            <ul>
                <li><strong>Stock ETFs:</strong> Track stock market indices</li>
                <li><strong>Bond ETFs:</strong> Invest in fixed-income securities</li>
                <li><strong>Sector ETFs:</strong> Focus on specific industries</li>
                <li><strong>International ETFs:</strong> Invest in foreign markets</li>
                <li><strong>Commodity ETFs:</strong> Track commodity prices</li>
            </ul>
            
            <h4>Advantages of ETFs:</h4>
            <ul>
                <li>Low expense ratios</li>
                <li>High liquidity</li>
                <li>Tax efficiency</li>
                <li>Diversification</li>
                <li>Transparency</li>
            </ul>
            
            <h4>Popular ETFs:</h4>
            <ul>
                <li><strong>SPY:</strong> S&P 500 ETF</li>
                <li><strong>QQQ:</strong> NASDAQ-100 ETF</li>
                <li><strong>VTI:</strong> Total Stock Market ETF</li>
                <li><strong>BND:</strong> Total Bond Market ETF</li>
            </ul>
        `
    }
};

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    initializePortfolioChart();
    loadPortfolioFromAPI();
    loadMarketIndices();
    setupEventListeners();
});

// Setup event listeners
function setupEventListeners() {
    // Risk assessment form
    const riskForm = document.getElementById('riskForm');
    if (riskForm) {
        riskForm.addEventListener('submit', handleRiskAssessment);
    }

    // Investment form
    const investmentForm = document.getElementById('investmentForm');
    if (investmentForm) {
        investmentForm.addEventListener('submit', handleAddInvestment);
    }

    // Modal close button
    const closeBtn = document.querySelector('.close');
    if (closeBtn) {
        closeBtn.addEventListener('click', closeModal);
    }

    // Close modal when clicking outside
    window.addEventListener('click', function(event) {
        const modal = document.getElementById('investmentModal');
        if (event.target === modal) {
            closeModal();
        }
    });
}

// Portfolio Chart
function initializePortfolioChart() {
    const ctx = document.getElementById('portfolioChart');
    if (!ctx) return;

    const labels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
    const data = [100000, 105000, 110000, 108000, 115000, 125430];

    new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Portfolio Value',
                data: data,
                borderColor: '#667eea',
                backgroundColor: 'rgba(102, 126, 234, 0.1)',
                borderWidth: 3,
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: false,
                    ticks: {
                        callback: function(value) {
                            return '$' + value.toLocaleString();
                        }
                    }
                }
            }
        }
    });
}

// Load portfolio data
function loadPortfolio() {
    const tbody = document.getElementById('portfolioBody');
    if (!tbody) return;

    tbody.innerHTML = '';
    
    portfolio.forEach(investment => {
        const totalValue = investment.quantity * investment.currentPrice;
        const totalCost = investment.quantity * investment.purchasePrice;
        const gainLoss = totalValue - totalCost;
        const gainLossPercent = ((gainLoss / totalCost) * 100).toFixed(2);
        
        const row = document.createElement('tr');
        row.innerHTML = `
            <td><strong>${investment.asset}</strong><br><small>${investment.symbol}</small></td>
            <td><span class="badge badge-${investment.type}">${investment.type.toUpperCase()}</span></td>
            <td>${investment.quantity}</td>
            <td>$${investment.currentPrice.toFixed(2)}</td>
            <td>$${totalValue.toLocaleString()}</td>
            <td class="${gainLoss >= 0 ? 'positive' : 'negative'}">
                ${gainLoss >= 0 ? '+' : ''}$${gainLoss.toFixed(2)} (${gainLossPercent}%)
            </td>
            <td>
                <button class="btn btn-small" onclick="editInvestment(${investment.id})">Edit</button>
                <button class="btn btn-small btn-danger" onclick="deleteInvestment(${investment.id})">Delete</button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

// Add investment modal
function addInvestment() {
    const modal = document.getElementById('investmentModal');
    modal.style.display = 'flex';
}

// Close modal
function closeModal() {
    const modal = document.getElementById('investmentModal');
    modal.style.display = 'none';
}

// Handle add investment form
function handleAddInvestment(event) {
    event.preventDefault();
    
    const formData = new FormData(event.target);
    const newInvestment = {
        id: portfolio.length + 1,
        asset: formData.get('assetName'),
        type: formData.get('assetType'),
        quantity: parseFloat(formData.get('quantity')),
        purchasePrice: parseFloat(formData.get('purchasePrice')),
        currentPrice: parseFloat(formData.get('purchasePrice')), // Start with purchase price
        symbol: formData.get('assetName').substring(0, 4).toUpperCase()
    };
    
    portfolio.push(newInvestment);
    loadPortfolio();
    closeModal();
    event.target.reset();
    
    // Show success message
    showNotification('Investment added successfully!', 'success');
}

// Edit investment
function editInvestment(id) {
    const investment = portfolio.find(inv => inv.id === id);
    if (!investment) return;
    
    // For simplicity, just update the current price
    const newPrice = prompt(`Enter new current price for ${investment.asset}:`, investment.currentPrice);
    if (newPrice && !isNaN(newPrice)) {
        investment.currentPrice = parseFloat(newPrice);
        loadPortfolio();
        showNotification('Investment updated successfully!', 'success');
    }
}

// Delete investment
function deleteInvestment(id) {
    if (confirm('Are you sure you want to delete this investment?')) {
        portfolio = portfolio.filter(inv => inv.id !== id);
        loadPortfolio();
        showNotification('Investment deleted successfully!', 'success');
    }
}

// Refresh portfolio data
function refreshData() {
    // Simulate fetching new data
    portfolio.forEach(investment => {
        // Simulate price changes
        const change = (Math.random() - 0.5) * 0.1; // ±5% change
        investment.currentPrice *= (1 + change);
    });
    
    loadPortfolio();
    showNotification('Portfolio data refreshed!', 'info');
}

// Show investment guide
function showGuide(type) {
    const guide = guides[type];
    if (!guide) return;
    
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.style.display = 'flex';
    
    modal.innerHTML = `
        <div class="modal-content" style="max-width: 800px; max-height: 80vh; overflow-y: auto;">
            <span class="close" onclick="this.parentElement.parentElement.remove()">&times;</span>
            <h2>${guide.title}</h2>
            <div class="guide-content">
                ${guide.content}
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Close modal when clicking outside
    modal.addEventListener('click', function(event) {
        if (event.target === modal) {
            modal.remove();
        }
    });
}

// Handle risk assessment
function handleRiskAssessment(event) {
    event.preventDefault();
    
    const formData = new FormData(event.target);
    const timeHorizon = parseInt(formData.get('timeHorizon'));
    const riskReaction = parseInt(formData.get('riskReaction'));
    const savingsRate = parseInt(formData.get('savingsRate'));
    
    // Calculate risk score (1-10)
    const riskScore = Math.round((timeHorizon + riskReaction + savingsRate) / 3);
    
    // Determine risk level
    let riskLevel, recommendations;
    
    if (riskScore <= 3) {
        riskLevel = 'Conservative';
        recommendations = [
            'Focus on bonds and fixed-income investments',
            'Consider high-quality dividend stocks',
            'Maintain a large emergency fund',
            'Avoid speculative investments'
        ];
    } else if (riskScore <= 6) {
        riskLevel = 'Moderate';
        recommendations = [
            'Balance between stocks and bonds',
            'Consider index funds for diversification',
            'Regular rebalancing of portfolio',
            'Moderate exposure to growth stocks'
        ];
    } else {
        riskLevel = 'Aggressive';
        recommendations = [
            'Higher allocation to stocks and growth investments',
            'Consider international markets for diversification',
            'Regular monitoring of portfolio performance',
            'Consider alternative investments'
        ];
    }
    
    // Display results
    document.getElementById('riskScore').textContent = riskScore;
    document.getElementById('riskLevel').textContent = riskLevel;
    
    const recommendationsList = document.getElementById('recommendations');
    recommendationsList.innerHTML = `
        <h4>Recommended Strategy:</h4>
        <ul>
            ${recommendations.map(rec => `<li>${rec}</li>`).join('')}
        </ul>
    `;
    
    document.getElementById('riskResults').style.display = 'block';
    
    // Scroll to results
    document.getElementById('riskResults').scrollIntoView({ behavior: 'smooth' });
}

// Show notification
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    
    // Add styles
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 1rem 1.5rem;
        border-radius: 8px;
        color: white;
        font-weight: 500;
        z-index: 1002;
        animation: slideIn 0.3s ease;
    `;
    
    if (type === 'success') {
        notification.style.background = '#10b981';
    } else if (type === 'error') {
        notification.style.background = '#ef4444';
    } else {
        notification.style.background = '#3b82f6';
    }
    
    document.body.appendChild(notification);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.remove();
    }, 3000);
}

// Add CSS for notifications
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    .badge {
        padding: 0.25rem 0.5rem;
        border-radius: 4px;
        font-size: 0.75rem;
        font-weight: 500;
        text-transform: uppercase;
    }
    
    .badge-stock { background: #dbeafe; color: #1e40af; }
    .badge-etf { background: #dcfce7; color: #166534; }
    .badge-crypto { background: #fef3c7; color: #92400e; }
    .badge-mutual-fund { background: #f3e8ff; color: #7c3aed; }
    
    .btn-small {
        padding: 0.25rem 0.5rem;
        font-size: 0.875rem;
        margin-right: 0.5rem;
    }
    
    .btn-danger {
        background: #ef4444;
        color: white;
    }
    
    .btn-danger:hover {
        background: #dc2626;
    }
    
    .guide-content {
        line-height: 1.8;
    }
    
    .guide-content h3 {
        color: #667eea;
        margin-bottom: 1rem;
    }
    
    .guide-content h4 {
        color: #333;
        margin: 1.5rem 0 0.5rem 0;
    }
    
    .guide-content ul {
        margin: 1rem 0;
        padding-left: 1.5rem;
    }
    
    .guide-content li {
        margin-bottom: 0.5rem;
    }
`;
document.head.appendChild(style);

// Enhanced functionality for professional features

// Sample news data
const newsData = [
    {
        id: 1,
        title: "Federal Reserve Signals Potential Rate Cut in Q2",
        summary: "The Federal Reserve hints at possible interest rate adjustments following recent economic indicators showing mixed signals in inflation and employment data.",
        category: "economy",
        date: "2024-11-09",
        time: "2 hours ago"
    },
    {
        id: 2,
        title: "Tech Stocks Rally on AI Breakthrough Announcements",
        summary: "Major technology companies see significant gains following announcements of new artificial intelligence capabilities and partnerships.",
        category: "stocks",
        date: "2024-11-09",
        time: "4 hours ago"
    },
    {
        id: 3,
        title: "Bitcoin Reaches New Monthly High Amid Institutional Adoption",
        summary: "Cryptocurrency markets surge as more institutional investors announce Bitcoin allocation strategies and regulatory clarity improves.",
        category: "crypto",
        date: "2024-11-08",
        time: "1 day ago"
    },
    {
        id: 4,
        title: "Energy Sector Outperforms as Oil Prices Stabilize",
        summary: "Energy stocks lead market gains as crude oil prices find stability around $85 per barrel, boosting investor confidence in the sector.",
        category: "stocks",
        date: "2024-11-08",
        time: "1 day ago"
    },
    {
        id: 5,
        title: "Global Markets React to Trade Agreement Progress",
        summary: "International markets show positive momentum following progress in trade negotiations between major economic powers.",
        category: "economy",
        date: "2024-11-07",
        time: "2 days ago"
    },
    {
        id: 6,
        title: "Ethereum Network Upgrade Boosts DeFi Activity",
        summary: "The latest Ethereum network improvements lead to increased activity in decentralized finance protocols and reduced transaction fees.",
        category: "crypto",
        date: "2024-11-07",
        time: "2 days ago"
    }
];

// Initialize enhanced features
document.addEventListener('DOMContentLoaded', function() {
    initializePortfolioChart();
    initializeSectorChart();
    loadPortfolio();
    loadNews();
    setupEventListeners();
    setupCalculators();
});

// Sector Chart
function initializeSectorChart() {
    const ctx = document.getElementById('sectorChart');
    if (!ctx) return;

    const sectorData = {
        labels: ['Technology', 'Healthcare', 'Financial', 'Energy', 'Consumer', 'Industrial'],
        datasets: [{
            label: 'Sector Performance (%)',
            data: [2.3, 1.8, -0.5, 3.2, 0.8, 1.2],
            backgroundColor: [
                '#667eea',
                '#764ba2',
                '#f093fb',
                '#f5576c',
                '#4facfe',
                '#43e97b'
            ],
            borderWidth: 0
        }]
    };

    new Chart(ctx, {
        type: 'bar',
        data: sectorData,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return value + '%';
                        }
                    }
                }
            }
        }
    });
}

// Load and display news
function loadNews(filter = 'all') {
    const newsGrid = document.getElementById('newsGrid');
    if (!newsGrid) return;

    const filteredNews = filter === 'all' ? newsData : newsData.filter(item => item.category === filter);
    
    newsGrid.innerHTML = filteredNews.map(item => `
        <div class="news-item" data-category="${item.category}">
            <div class="news-meta">
                <span class="news-category">${item.category.toUpperCase()}</span>
                <span class="news-time">${item.time}</span>
            </div>
            <h4>${item.title}</h4>
            <p>${item.summary}</p>
        </div>
    `).join('');
}

// Filter news by category
function filterNews(category) {
    // Update active filter button
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    event.target.classList.add('active');
    
    // Load filtered news
    loadNews(category);
}

// Calculator functions
function setupCalculators() {
    // Auto-calculate on input change
    const calculatorInputs = document.querySelectorAll('#compound-calculator input');
    calculatorInputs.forEach(input => {
        input.addEventListener('input', calculateCompound);
    });
}

function showCalculator(type) {
    // Update active tab
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    event.target.classList.add('active');
    
    // Show selected calculator
    document.querySelectorAll('.calculator-content').forEach(content => {
        content.classList.remove('active');
    });
    document.getElementById(`${type}-calculator`).classList.add('active');
}

function calculateCompound() {
    const initialAmount = parseFloat(document.getElementById('initialAmount')?.value) || 0;
    const monthlyContribution = parseFloat(document.getElementById('monthlyContribution')?.value) || 0;
    const annualRate = parseFloat(document.getElementById('interestRate')?.value) || 0;
    const years = parseFloat(document.getElementById('investmentYears')?.value) || 0;
    
    if (years === 0) return;
    
    const monthlyRate = annualRate / 100 / 12;
    const totalMonths = years * 12;
    
    // Future value of initial investment
    const futureValueInitial = initialAmount * Math.pow(1 + monthlyRate, totalMonths);
    
    // Future value of monthly contributions
    const futureValueContributions = monthlyContribution * 
        ((Math.pow(1 + monthlyRate, totalMonths) - 1) / monthlyRate);
    
    const totalValue = futureValueInitial + futureValueContributions;
    const totalContributions = initialAmount + (monthlyContribution * totalMonths);
    const totalInterest = totalValue - totalContributions;
    
    const resultsDiv = document.getElementById('compoundResults');
    if (resultsDiv) {
        resultsDiv.innerHTML = `
            <div class="result-item">
                <div class="result-value">$${totalValue.toLocaleString('en-US', {maximumFractionDigits: 0})}</div>
                <div class="result-label">Final Amount</div>
            </div>
            <div class="result-item">
                <div class="result-value">$${totalContributions.toLocaleString('en-US', {maximumFractionDigits: 0})}</div>
                <div class="result-label">Total Contributions</div>
            </div>
            <div class="result-item">
                <div class="result-value">$${totalInterest.toLocaleString('en-US', {maximumFractionDigits: 0})}</div>
                <div class="result-label">Interest Earned</div>
            </div>
        `;
    }
}

function calculateRetirement() {
    const currentAge = parseFloat(document.getElementById('currentAge')?.value) || 0;
    const retirementAge = parseFloat(document.getElementById('retirementAge')?.value) || 0;
    const currentSavings = parseFloat(document.getElementById('currentSavings')?.value) || 0;
    const monthlySavings = parseFloat(document.getElementById('monthlySavings')?.value) || 0;
    const expectedReturn = parseFloat(document.getElementById('expectedReturn')?.value) || 0;
    const desiredIncome = parseFloat(document.getElementById('desiredIncome')?.value) || 0;
    
    const yearsToRetirement = retirementAge - currentAge;
    const monthlyRate = expectedReturn / 100 / 12;
    const totalMonths = yearsToRetirement * 12;
    
    // Calculate future value of current savings and monthly contributions
    const futureCurrentSavings = currentSavings * Math.pow(1 + monthlyRate, totalMonths);
    const futureMonthlySavings = monthlySavings * 
        ((Math.pow(1 + monthlyRate, totalMonths) - 1) / monthlyRate);
    
    const totalRetirementSavings = futureCurrentSavings + futureMonthlySavings;
    
    // Calculate required savings for desired income (4% withdrawal rule)
    const requiredSavings = desiredIncome * 12 / 0.04;
    const shortfall = Math.max(0, requiredSavings - totalRetirementSavings);
    
    const resultsDiv = document.getElementById('retirementResults');
    if (resultsDiv) {
        resultsDiv.innerHTML = `
            <div class="result-item">
                <div class="result-value">$${totalRetirementSavings.toLocaleString('en-US', {maximumFractionDigits: 0})}</div>
                <div class="result-label">Projected Retirement Savings</div>
            </div>
            <div class="result-item">
                <div class="result-value">$${requiredSavings.toLocaleString('en-US', {maximumFractionDigits: 0})}</div>
                <div class="result-label">Required for Desired Income</div>
            </div>
            <div class="result-item">
                <div class="result-value ${shortfall > 0 ? 'text-red' : 'text-green'}">
                    ${shortfall > 0 ? '-' : '+'}$${Math.abs(shortfall).toLocaleString('en-US', {maximumFractionDigits: 0})}
                </div>
                <div class="result-label">${shortfall > 0 ? 'Shortfall' : 'Surplus'}</div>
            </div>
        `;
    }
}

function calculateLoan() {
    const loanAmount = parseFloat(document.getElementById('loanAmount')?.value) || 0;
    const annualRate = parseFloat(document.getElementById('loanRate')?.value) || 0;
    const loanTermYears = parseFloat(document.getElementById('loanTerm')?.value) || 0;
    const downPayment = parseFloat(document.getElementById('downPayment')?.value) || 0;
    
    const principal = loanAmount - downPayment;
    const monthlyRate = annualRate / 100 / 12;
    const totalPayments = loanTermYears * 12;
    
    // Calculate monthly payment using loan formula
    const monthlyPayment = principal * 
        (monthlyRate * Math.pow(1 + monthlyRate, totalPayments)) / 
        (Math.pow(1 + monthlyRate, totalPayments) - 1);
    
    const totalPaid = monthlyPayment * totalPayments;
    const totalInterest = totalPaid - principal;
    
    const resultsDiv = document.getElementById('loanResults');
    if (resultsDiv) {
        resultsDiv.innerHTML = `
            <div class="result-item">
                <div class="result-value">$${monthlyPayment.toLocaleString('en-US', {maximumFractionDigits: 2})}</div>
                <div class="result-label">Monthly Payment</div>
            </div>
            <div class="result-item">
                <div class="result-value">$${totalPaid.toLocaleString('en-US', {maximumFractionDigits: 0})}</div>
                <div class="result-label">Total Amount Paid</div>
            </div>
            <div class="result-item">
                <div class="result-value">$${totalInterest.toLocaleString('en-US', {maximumFractionDigits: 0})}</div>
                <div class="result-label">Total Interest</div>
            </div>
        `;
    }
}

// Theme toggle
function toggleTheme() {
    document.body.classList.toggle('dark-theme');
    const themeBtn = document.querySelector('.nav-actions .btn-outline');
    if (themeBtn) {
        themeBtn.textContent = document.body.classList.contains('dark-theme') ? '☀️' : '🌙';
    }
    
    // Save theme preference
    localStorage.setItem('theme', document.body.classList.contains('dark-theme') ? 'dark' : 'light');
}

// Load saved theme
function loadTheme() {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark') {
        document.body.classList.add('dark-theme');
        const themeBtn = document.querySelector('.nav-actions .btn-outline');
        if (themeBtn) {
            themeBtn.textContent = '☀️';
        }
    }
}

// Contact form handler
function setupContactForm() {
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', function(event) {
            event.preventDefault();
            
            const formData = new FormData(event.target);
            const contactData = {
                name: formData.get('name'),
                email: formData.get('email'),
                subject: formData.get('subject'),
                message: formData.get('message')
            };
            
            // Simulate form submission
            showNotification('Message sent successfully! We\'ll get back to you soon.', 'success');
            event.target.reset();
        });
    }
}

// Newsletter subscription
function setupNewsletterForm() {
    const newsletterForm = document.querySelector('.newsletter-form');
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', function(event) {
            event.preventDefault();
            const email = event.target.querySelector('input[type="email"]').value;
            
            if (email) {
                showNotification('Successfully subscribed to newsletter!', 'success');
                event.target.reset();
            }
        });
    }
}

// Enhanced setup
document.addEventListener('DOMContentLoaded', function() {
    loadTheme();
    setupContactForm();
    setupNewsletterForm();
    
    // Auto-calculate compound interest on page load
    setTimeout(calculateCompound, 100);
});

// Smooth scrolling for navigation links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Add loading states for better UX
function showLoading(elementId) {
    const element = document.getElementById(elementId);
    if (element) {
        element.innerHTML = '<div class="loading"></div>';
    }
}

// Enhanced portfolio refresh with loading state
function refreshData() {
    showLoading('portfolioBody');
    
    setTimeout(() => {
        // Simulate fetching new data
        portfolio.forEach(investment => {
            const change = (Math.random() - 0.5) * 0.1;
            investment.currentPrice *= (1 + change);
        });
        
        loadPortfolio();
        showNotification('Portfolio data refreshed!', 'info');
    }, 1000);
}

// Add CSS for additional utility classes
const additionalStyles = document.createElement('style');
additionalStyles.textContent = `
    .text-red { color: #ef4444 !important; }
    .text-green { color: #10b981 !important; }
    .text-center { text-align: center; }
    
    .fade-in {
        animation: fadeIn 0.5s ease-in;
    }
    
    @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
    }
`;
document.head.appendChild(additionalStyles);