// Finance Wizards - Production Configuration

const CONFIG = {
    // Deployment URLs
    PRODUCTION_URLS: {
        vercel: 'https://finance-wizards.vercel.app',
        netlify: 'https://finance-wizards.netlify.app',
        github: 'https://chetan11223.github.io/finbuble-11',
        railway: 'https://finance-wizards.railway.app',
        render: 'https://finance-wizards.onrender.com'
    },
    
    // Telegram Configuration
    TELEGRAM: {
        channels: {
            main: 'https://t.me/financewizards_main',
            alerts: 'https://t.me/financewizards_alerts',
            education: 'https://t.me/financewizards_education',
            premium: 'https://t.me/financewizards_premium'
        },
        bot: {
            username: '@financewizards_bot',
            url: 'https://t.me/financewizards_bot'
        }
    },
    
    // API Configuration
    API: {
        timeout: 10000,
        retries: 3,
        fallbackMode: true
    },
    
    // Feature Flags
    FEATURES: {
        telegramIntegration: true,
        realTimeData: true,
        premiumFeatures: true,
        analytics: true,
        darkMode: true
    },
    
    // Indian Market Configuration
    MARKET: {
        currency: 'INR',
        symbol: '₹',
        locale: 'en-IN',
        timezone: 'Asia/Kolkata',
        tradingHours: {
            start: '09:15',
            end: '15:30'
        }
    }
};

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
    module.exports = CONFIG;
} else {
    window.CONFIG = CONFIG;
}